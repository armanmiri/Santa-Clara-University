SELECT kind, model
FROM Observer
WHERE kind = 'camera'
  AND software_version = '1.9';
